# Seaborn
Seaborn works on top of matplotlib, and is especially strong for plotting
data and its statistical properties.

## What is it?
1. `seaborn.ipynb`: Jupyter notebook that illustrates a number of Seaborn
    features.
1. `generate_data.py`: script to generate example data.
1. `Data`: directory containing example data.
