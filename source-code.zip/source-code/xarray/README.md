# Xarray

xarray is a Python package to represent numerical data with metadata.  In that respect it is
a hybrid between numpy and pandas.

## What is it?

1. `xarray_intro.ipynb`: Jupyter notebook introducing some of xarray's features.
